#!/usr/bin/env python2
# vim:fileencoding=utf-8
from __future__ import absolute_import, division, print_function, unicode_literals

__license__ = 'GPL v3'
__copyright__ = '2014, Kovid Goyal <kovid at kovidgoyal.net>'

# Standard libraries
import re
from lxml import etree
from collections import defaultdict
from polyglot.builtins import iteritems, itervalues, unicode_type, filter

# PyQt libraries
from PyQt5.Qt import QAction
from css_parser.css import CSSRule

# Calibre libraries
from calibre.gui2.tweak_book.plugin import Tool
from calibre import force_unicode
from calibre.gui2 import error_dialog
from calibre.ebooks.oeb.base import OPF, OEB_DOCS, OEB_STYLES, XPNSMAP, XPath, XHTML, serialize, barename, etree
from calibre.ebooks.oeb.polish.container import OEB_FONTS
from calibre.ebooks.oeb.polish.css import remove_unused_css
from calibre.ebooks.oeb.polish.replace import rename_files, rationalize_folders
from calibre.ebooks.oeb.polish.toc import get_toc, commit_toc, TOC

from calibre_plugins.reformat_epub.__init__ import PLUGIN_VERSION

class TReformat(Tool):

    #: Set this to a unique name it will be used as a key
    name = 'demo-tool'

    #: If True the user can choose to place this tool in the plugins toolbar
    allowed_in_toolbar = True

    #: If True the user can choose to place this tool in the plugins menu
    allowed_in_menu = True

    def create_action(self, for_toolbar=True):
        # Create an action, this will be added to the plugins toolbar and
        # the plugins menu
        version = '.'.join([str(x) for x in PLUGIN_VERSION])
        ac = QAction(get_icons('images/icon.png'), 'Reformat ver. ' + version, self.gui)  # noqa
        if not for_toolbar:
            # Register a keyboard shortcut for this toolbar action. We only
            # register it for the action created for the menu, not the toolbar,
            # to avoid a double trigger
            self.register_shortcut(ac, 'reformat-tool', default_keys=('Ctrl+Shift+Alt+D',))
        ac.triggered.connect(self.reformat)
        return ac

    #def ask_user(self):
    #    # Ask the user for a factor by which to multiply all font sizes
    #    factor, ok = QInputDialog.getDouble(
    #        self.gui, 'Enter a magnification factor', 'Allow font sizes in the book will be multiplied by the specified factor',
    #        value=2, min=0.1, max=4
    #    )
    #    if ok:
    #        # Ensure any in progress editing the user is doing is present in the container
    #        self.boss.commit_all_editors_to_container()
    #        try:
    #            self.magnify_fonts(factor)
    #        except Exception:
    #            # Something bad happened report the error to the user
    #            import traceback
    #            error_dialog(self.gui, _('Failed to magnify fonts'), _(
    #                'Failed to magnify fonts, click "Show details" for more info'),
    #                det_msg=traceback.format_exc(), show=True)
    #            # Revert to the saved restore point
    #            self.boss.revert_requested(self.boss.global_undo.previous_container)
    #        else:
    #            # Show the user what changes we have made, allowing her to
    #            # revert them if necessary
    #            self.boss.show_current_diff()
    #            # Update the editor UI to take into account all the changes we
    #            # have made
    #            self.boss.apply_container_update_to_gui()

    def reduce(self, elem):

        def moveText(text):
            if text != None:
                prev = elem.getprevious()
                if prev != None:
                    if prev.tail == None: prev.tail = ''
                    prev.tail += text
                else:
                    if parent.text == None: parent.text = ''
                    parent.text += text

        parent = elem.getparent()
        moveText(elem.text)
        for child in elem.iterchildren():
            elem.addprevious(child);
        moveText(elem.tail)
        parent.remove(elem)

    def detext(self, elem):
        if elem.text != None and elem.text.strip() != '':
            child = etree.Element(XHTML('p'))
            child.text = elem.text.strip()
            elem.insert(0, child)
        elem.text = '\n'
        if elem.tail != None and elem.tail.strip() != '':
            child = etree.SubElement(elem, XHTML('p'))
            child.text = elem.tail.strip()
        elem.tail = '\n'

    def getcontent(self, elem):
        return ' '.join(elem.itertext())    

    def remove_spans(self):
        container = self.current_container
        root = container.parsed(self.docName)

        nodes = root.xpath('//comment()');
        for node in nodes:
            node.getparent().remove(node);

        def find_anchor(el):
            for anchor in el.iterdescendants():
                if barename(anchor.tag) == "a": return anchor
            anchor = el
            while anchor != None:
                if barename(anchor.tag) == "a": return anchor
                anchor = anchor.getnext()
            anchor = el
            while anchor != None:
                if barename(anchor.tag) == "a": return anchor
                anchor = anchor.getprevious()
            anchor = el
            while anchor != None:
                if barename(anchor.tag) == "a": return anchor
                anchor = anchor.getparent()
            return None

        headers = root.xpath('//*[@id]', namespaces = XPNSMAP)
        for el in headers:
            id = el.get('id')
            if barename(el.tag) != "a":
                anchor = find_anchor(el)
                if anchor != None and not 'id' in anchor.attrib:
                    anchor.set('id', id)
                else:
                    anchor = etree.Element(XHTML('a'))
                    anchor.set('id', id)
                    el.insert(0, anchor)
                el.attrib.pop('id')

        headers = root.xpath('//h:span', namespaces = XPNSMAP)
        for el in headers:
            text = el.text
            #if len(el) > 0 and barename(el[0].tag) == 'img':
            if len(el) > 0 and etree.QName(el[0]).localname == 'img':
                continue
            if text == None or text.strip() == '' or not "class" in el.attrib:
                self.reduce(el)
                continue
            classname = el.attrib["class"].lower()
            if classname == "bold":
                el.tag = '{%s}b' % XPNSMAP['h']
                continue
            if classname == "italic":
                el.tag = '{%s}i' % XPNSMAP['h']
                continue
            if classname == "underline":
                el.tag = '{%s}u' % XPNSMAP['h']
                continue
            #parent = el.getparent()
            #nextSibling = el.getnext()
            #if nextSibling == None:
            #    if el.tail != None:
            #        el.tail = el.tail.rstrip()
            #        if (el.tail != ''): continue
            #    if len(parent) > 1:
            #        continue
            #    parentText = parent.text;
            #    if parentText == None or parentText.strip() == '':
            #        #if not "class" in parent.attrib:
            #        parent.attrib["class"] = el.attrib["class"]
            #        self.reduce(el)
            #    continue

            #tail = el.tail;
            #if tail != None and tail.strip() == '':
            #    tail = None;

        headers = root.xpath('//h:br', namespaces = XPNSMAP)
        for el in headers:
            parent = el.getparent()
            tag = barename(parent.tag)
            if tag in ['section', 'body'] and (el.tail == None or el.tail.strip() == ''):
                self.reduce(el)
            elif tag == 'p':
                split_idx = parent.index(el)
                p = etree.Element(XHTML('p'))
                children = parent[:split_idx]
                for child in children:
                    parent.remove(child)
                    p.append(child)
                p.text = parent.text
                parent.text = None
                self.reduce(el)
                parent.addprevious(p)

        headers = root.xpath('//h:p', namespaces = XPNSMAP)
        for el in headers:
            parent = el.getparent()
            if barename(parent.tag) == 'p':
                #self.detext(parent)
                #self.reduce(parent)
                #continue
                split_idx = parent.index(el)
                children = parent[split_idx:]
                next = parent
                for child in children:
                    parent.remove(child)
                    next.addnext(child)
                    next = child
                continue
            content = self.getcontent(el)
            if content.strip() == '':
                if len(el) > 0 and el[0].tag != None and barename(el[0].tag) == 'img':
                    el.attrib.clear()
                    el.tag = '{%s}center' % XPNSMAP['h']
                else:
                    self.reduce(el)
                continue
            if '\n' in content:
                if (el.text != None):
                    el.text = re.sub('\n', ' ', el.text)
                for child in el.iterdescendants():
                    if child.text != None:
                        child.text = re.sub('\n', ' ', child.text)
                    if child.tail != None:
                        child.tail = re.sub('\n', ' ', child.tail)
            if el.text == None:
                continue
            if len(el) == 0:
                el.text = el.text.strip()
            else:
                el.text = el.text.lstrip()

        headers = root.xpath('//h:i', namespaces = XPNSMAP)
        if len(headers) == 0:
            headers = root.xpath('//h:em', namespaces = XPNSMAP)
            for header in headers:
                header.tag = '{%s}i' % XPNSMAP['h']
            headers = root.xpath('//h:strong', namespaces = XPNSMAP)
            for header in headers:
                header.tag = '{%s}b' % XPNSMAP['h']

        headers = root.xpath('//h:div', namespaces = XPNSMAP)
        inlines = ['i', 'b', 'em', 'strong', 'q', 'small', 'img']
        for header in headers:
            valid = False
            if (header.text != None and header.text.strip() != ''):
                valid = True
            elif len(header) > 0 and header[0].tag != None and barename(header[0].tag) in inlines:
                valid = True
            if valid:
                header.tag = '{%s}center' % XPNSMAP['h']
                #header.attrib.clear()
            else:
                self.reduce(header)

        #notes = {}
        #headers = root.xpath('//h:dt', namespaces = XPNSMAP)
        #    term = ' '.join(el.itertext())
        #    term = re.sub(r'\[[0-9]+\]','', term)
        #for el in headers:
        #    data = el.getnext()
        #    if data == None:
        #        continue
        #    term = term + ' '.join(data.itertext())
        #    if not term in notes:
        #        notes[term] = data.text
        #    else:
        #        el.getparent().remove(data)
        #        el.getparent().remove(el)

        #tags_with_attrib = ['p', 'span', 'a', 'link', 'img', 'h1', 'h2']
        attributes = {};
        attributes['i'] = 'lang';
        attributes['b'] = '';
        attributes['u'] = '';
        attributes['br'] = '';
        attributes['sub'] = '';
        attributes['sup'] = '';
        attributes['small'] = '';
        attributes['em'] = '';
        attributes['strong'] = '';
        attributes['img'] = 'src';
        attributes['ol'] = 'type';
        for item in root.iterdescendants():
            tag = barename(item.tag)
            #item.tag = etree.QName(item).localname
            if tag == 'a':
                for attr in item.attrib:
                    if not attr in ['id', 'href']:
                        item.attrib.pop(attr)
            elif not tag in ['link', 'span', 'h1', 'h2']:
                if not tag in attributes:
                    attributes[tag] = 'class'
                if attributes[tag] != '':
                    attrib = item.get(attributes[tag], None)
                else:
                    attrib = None
                item.attrib.clear()
                if attrib != None:
                    item.set(attributes[tag], attrib)
            if barename(item.getparent().tag) in ['p', 'body', 'section']:
                if item.tail == None or item.tail.strip() == '':
                    item.tail = '\n'
            #elif tag not in ['p', 'br']:
            #    if item.tail == '\n':
            #        item.tail = None
            #if item.text != None and item.text.strip() == '': item.text = item.text.replace(' ','')
            #if item.tail != None and item.tail.strip() == '': item.tail = item.tail.replace(' ','')
        etree.cleanup_namespaces(root)

        container.dirty(self.docName)

    def trim(self):
        container = self.current_container
        raw = container.raw_data(self.docName)
        raw = re.sub('([ \t\u00a0]+)', ' ', raw)
        #raw = re.sub('\n ', '\n', raw)
        raw = re.sub('(\n\n+)', '\n', raw)
        #raw = re.sub(r'([^<>])\n([^<>])', r'\1 \2', raw)
        raw = re.sub(r' </p>', r'</p>', raw)
        raw = re.sub(r'</p>\n<p>([a-z,ć,ł,ó,ś,ź,ż])', r' \1', raw)
        raw = re.sub(r'- ([a-z,ć,ł,ń,ś,ź,ż])', r'\1', raw)
        #raw = re.sub(r'<(p|center)>(-* *[0-9]+ *-*)</\1>\n', '', raw)
        #raw = re.sub(r'<center>(-* *[0-9]+ *-*)</center>\n', '', raw)
        raw = re.sub(r'<p>\* \* \*</p>', r'<hr/>', raw)
        #raw = re.sub(r'</i>\n<i>', r' ', raw)
        raw = re.sub(r'</i><i>', r'', raw)
        container.open(self.docName, 'w').write(raw)

    def remove_dummy_selectors(self):
        container = self.current_container
        sheet = container.parsed(self.styleName)
        fonts = list(container.manifest_items_of_type(OEB_FONTS));
        dummies = []
        self.chapterstyle = ''
        for rule in sheet.cssRules:
            #print('*')
            if rule.type != rule.STYLE_RULE:
                if rule.type == rule.FONT_FACE_RULE:
                    val = rule.style.getPropertyValue('src')
                    href = val[val.find('(') + 1: val.find(')')]
                    fname = container.href_to_name(href, self.styleName)
                    if not fname in fonts:
                        dummies.append(rule)
                continue
            selector = rule.selectorText.split('.')
            tag = selector[0]
            classtag = selector[-1]
            if tag == 'a':
                ref_name = rule.style.getPropertyValue('content')
                if ref_name != '':
                    self.ref_name = ref_name[1:-1]
            if tag != '':
                continue
            if classtag == 'regular':
                continue
            fontSize = 1
            val = rule.style.getPropertyValue('font-size')
            num = re.search(r'[0-9.]+', val)
            if num is not None:
                num = num.group()
                fontSize = float(num)
                if fontSize == 100:
                    fontSize = 1
            elif val != '' and val != 'medium':
                fontSize = 0
            fontFamily = rule.style.getPropertyValue('font-family')
            fontStyle = rule.style.getPropertyValue('font-style')
            fontWeight = rule.style.getPropertyValue('font-weight')
            align = rule.style.getPropertyValue('text-align')
            decor = rule.style.getPropertyValue('text-decoration')
            if (fontStyle == 'normal'):
                fontStyle = ''
            if (fontWeight == 'normal'):
                fontWeight = ''
            if (fontWeight == 'bold'):
                self.chapterstyle = classtag #rule.selectorText.rsplit('.', 1)[-1]
            if (align == 'left' or align == 'justify'):
                align = ''
            if decor != '' and decor != 'none':
                continue
            if (fontSize == 1 and fontFamily == '' and fontStyle == '' and fontWeight == '' and align == ''):
                dummies.append(rule)
                #print('dummy')

        for rule in dummies:
            sheet.cssRules.remove(rule)
        container.dirty(self.styleName)
        return len(dummies)

    def checkHeaders(self, headers, dstTag):
        inlines = ['i', 'b', 'em', 'strong', 'q', 'small', 'a', 'img', 'span']
        count = 0
        for header in headers:
            #print(header.tag)
            #print(header.text)
            tag = barename(header.tag)
            if tag in inlines:
                self.reduce(header)
                continue
            if barename(header.getparent().tag) == 'intro':
                continue
            if header.getnext() in headers:
                continue
            if header.getprevious() in headers:
                continue
            #if dstTag == 'h1':
            #    next = header.getnext()
            #    if next == None or barename(next.tag) != 'h2':
            #        continue

            header.tag = '{%s}%s' % (XPNSMAP['h'], dstTag)
            #header.attrib.clear()
            if header.tail == None or header.tail.strip() == '':
                header.tail = '\n'
            if dstTag == 'h1' or dstTag == 'h2':
                header.set('split-point', '1')
            count += 1
        return count                         

    def insert_sections(self):
        container = self.current_container
        root = container.parsed(self.docName)
        headers = root.xpath("h:body/h:section", namespaces = XPNSMAP)
        if len(headers) > 0:
            body = root.find('h:body', namespaces = XPNSMAP)
            child = body[0];
            if child != headers[0]:
                prev_section = body.makeelement(XHTML('section'))
                body.insert(0, prev_section)
            headers.append(None)
            for section in headers:
                while child != section:
                    next = child.getnext()
                    body.remove(child)
                    prev_section.append(child)
                    child = next
                if section != None:
                    self.detext(section)
                    child = section.getnext()
                prev_section = section
        else:
            self.detectChapters()
               
    def detectChapters(self):
        container = self.current_container
        root = container.parsed(self.docName)

        #headers = root.xpath("//*[name()='h1' or name()='h2']", namespaces = XPNSMAP)
        headers = root.xpath("//h:h2", namespaces = XPNSMAP)
        chapter_count = self.checkHeaders(headers, 'h2')
        headers = root.xpath("//h:h1", namespaces = XPNSMAP)
        if len(headers) < 2:
            headers = root.xpath("//*[re:match(., '^(część|tom|part)\s([IVX]+|[0-9]+)', 'i')]", namespaces = XPNSMAP)
        chapter_count += self.checkHeaders(headers, 'h1')
        headers = root.xpath("//*[re:match(., '^(rozdział|prolog|epilog|chapter|chapitre|kapitel)', 'i')]", namespaces = XPNSMAP)
        chapter_count += self.checkHeaders(headers, 'h2')
        headers = root.xpath("//*[re:match(., '^[IVX]+\.? ?$')]", namespaces = XPNSMAP)
        if chapter_count < 2:
            chapter_count = self.checkHeaders(headers, 'h2')
        else:
            self.checkHeaders(headers, 'h3')
        #if chapter_count == 0:
        #    headers = root.xpath("//h:h1", namespaces = XPNSMAP)
        #    chapter_count = self.checkHeaders(headers, 'h2')
        if chapter_count < 2:
            headers = self.headers_from_toc()
            if len(headers) > 1:
                for header in headers:
                    header.set('split-point', '1')
                chapter_count = len(headers)
        if chapter_count == 0:
            headers = root.xpath('//*[@class="%s"]' % self.chapterstyle)
            self.checkHeaders(headers, 'h2')
        #headers = root.xpath("//h:h1", namespaces = XPNSMAP)
        #if len(headers) < 2:
        #    headers = root.xpath("//h:p[re:match(., '^część|^tom\s|^part\s', 'i')]", namespaces = XPNSMAP)
        #self.checkHeaders(headers, 'h1')

        headers = root.xpath('//*[@split-point]')
        body = root.find('h:body', namespaces = XPNSMAP)
        self.detext(body)
        node = body[0]
        headers.append(None)
        newBody = root.makeelement(XHTML('body'))
        for header in headers:
            if header != None:
                header.attrib.clear()
            section = body.makeelement(XHTML('section'))
            endNode = header
            while endNode != None and endNode.getparent() != body:
                endNode = endNode.getparent()
            while node != endNode:
                nextNode = node.getnext()
                section.append(node)
                node = nextNode
            if len(section) > 0:
                if len(section[0]) == 0 and section[0].text == None:
                    section.remove(section[0])
                newBody.append(section)
        root.replace(body, newBody)
        container.dirty(self.docName)

    def headers_from_toc(self):
        container = self.current_container
        root = container.parsed(self.docName)
        toc = get_toc(container, False)
        anchors = root.xpath('//*[@id]', namespaces = XPNSMAP)
        headers = []
        for item in toc.iterdescendants():
            section = next((x for x in anchors if x.get('id') == item.frag), None)
            if section == None:
                continue
            if item.parent == toc or item.parent.parent == toc:
                headers.append(section)
        return headers       
    
    def toc_from_headers(self):
        container = self.current_container
        toc = TOC()
        base = toc
        toc_level = 0
        path = "//*[name()='h1' or name()='h2' or name()='h3']"
        for name, is_linear in container.spine_names:
            root = container.parsed(name)
            headers = root.xpath(path)
            for header in headers:
                if barename(header.getparent().tag) == 'intro':
                    continue
                h_level = int(barename(header.tag)[-1])
                text = self.getcontent(header)
                if h_level > toc_level:
                    base = base.add(text, name)
                elif h_level == toc_level:
                    base = base.parent.add(text, name)
                else:
                    for i in range(h_level, toc_level):
                        if base.parent == toc:
                            break
                        base = base.parent
                    base = base.parent.add(text, name)
                toc_level = h_level
        commit_toc(container, toc)

    def split(self):
        container = self.current_container
        spine = container.opf_xpath('//opf:spine')[0]
        for spine_item, spine_name, linear in container.spine_iter:
            if spine_name == self.docName:
                break
        index = spine.index(spine_item) + 1

        root = container.parsed(self.docName)
        body = root.find('h:body', namespaces = XPNSMAP)
        anchors = root.xpath("//h:a", namespaces = XPNSMAP)
        anchor_map = {}
        refs = []
        for anchor in anchors:
            anchor_map[anchor] = -1
            if len(anchor.attrib) == 0:
                self.reduce(anchor)
            href = anchor.get('href')
            if href == None: continue
            ref_id = href.rsplit('#',1)[-1]
            if ref_id == href: continue
            for anchor_nr, ref_anchor in enumerate(anchors):
                if ref_anchor.get('id') == ref_id:
                    anchor_map[anchor] = anchor_nr
                    refs.append(ref_anchor)
                    break
            if anchor_map[anchor] < 0:
                id = anchor.get('id')
                if id == None:
                    self.reduce(anchor)

        for anchor in anchors:
            anchor_nr = anchor_map[anchor]
            if anchor_nr < 0:
                id = anchor.get('id')
                if id != None:
                    if re.sub(r'([0-9]+)','', id) == self.ref_name or self.getcontent(anchor) == '':
                        if not anchor in refs:
                            self.reduce(anchor)
                continue
            ref_anchor = anchors[anchor_nr]
            section = ref_anchor
            while section.getparent() != body:
                section = section.getparent()
                if section == None: break
            ref_id = '%s%d' % (self.ref_name, anchor_nr)
            ref_anchor.set('id', ref_id)
            if section != None:
                anchor.set('href', '%03d.xhtml#%s' % (body.index(section), ref_id))

        sections = root.xpath("h:body/h:section", namespaces = XPNSMAP)
        for i, section in enumerate(sections):
            if len(section) == 0:
                continue
            filename = "%03d.xhtml" % i
            manifest_item = container.generate_item(filename, media_type = container.mime_map[self.docName])
            sname = container.href_to_name(manifest_item.get('href'), container.opf_name)
            sroot = etree.Element(XHTML('html'), nsmap = {None: '%s' % XPNSMAP['h']})
            sroot.text = '\n'
            head = etree.SubElement(sroot, XHTML('head'))
            head.text = '\n'
            head.tail = '\n'
            path = container.name_to_href(self.styleName, self.docName)
            link = etree.SubElement(head, XHTML('link'), rel = 'stylesheet', type = 'text/css', href = path)
            link.tail = '\n'
            body = etree.SubElement(sroot, XHTML('body'))
            body.text = '\n'
            body.tail = '\n'
            body.append(section)
            self.detext(section)
            container.replace(sname, sroot)
            si = spine.makeelement(OPF('itemref'), idref = manifest_item.get('id'))
            container.insert_into_xml(spine, si, index = index + i)
        container.remove_item(self.docName)
        container.dirty(container.opf_name)

    def mergeDocs(self):

        def check_anchors():
            name_map = {}
            repeatedID = {}
            anchors_valid = True
            for name_nr, name in enumerate(docs):
                name_map[name] = name_nr
                root = container.parsed(name)
                anchors = root.xpath('//*[@id or @name]', namespaces = XPNSMAP)
                for anchor in anchors:
                    id = anchor.get('id')
                    if (id == None):
                        id = anchor.get('name')
                        anchor.attrib.pop('name')
                        anchor.set('id', id)
                    found = id in repeatedID
                    repeatedID[id] = found
                    if found:
                        anchors_valid = False
            if anchors_valid: return
            for name in docs:
                root = container.parsed(name)
                anchors = root.xpath('//*[@id]', namespaces = XPNSMAP)
                for anchor in anchors:
                    id = anchor.get('id')
                    if repeatedID.get(id, False):
                        anchor.set('id','%s%03d' % (id, name_map[name]))
                anchors = root.xpath('//*[@href]', namespaces = XPNSMAP)
                for anchor in anchors:
                    href = anchor.get('href')
                    id = href.split('#')
                    if len(id) != 2: continue
                    if repeatedID.get(id[1], False):
                        fname = container.href_to_name(href, name)
                        if fname == None: fname = name
                        idx = name_map.get(fname, -1)
                        if idx >= 0:
                            anchor.set('href','%s#%s%03d' % (id[0], id[1], idx))

        container = self.current_container
        docs = list(name for item, name, linear in container.spine_iter)        # docs in spine order
        cover_name = container.guide_type_map.get('cover', None)
        if (docs[0] == cover_name or docs[0] == 'titlepage.xhtml'):
            docs.pop(0)
        master = docs[0]
        if len(docs) > 1:
            master_body = container.parsed(master).find('h:body', namespaces = XPNSMAP)
            check_anchors()
            for name in docs:
                if name == master or name == cover_name: continue
                root = container.parsed(name)
                body = root.find('h:body', namespaces = XPNSMAP)
                self.detext(body)
                if self.firstRun:
                    header = body[0]
                    if header != None and not barename(header.tag) == 'section':
                        if not barename(header.tag) in ['h1', 'h2']:
                            child = etree.Element(XHTML('h2'))
                            body.insert(0, child)
                        else:
                            header.set('split-point', '1')
                master_body.extend(body)
                container.remove_item(name)
            container.dirty(master)
        if (master != self.docName):
            rename_files(container, {master: self.docName})

    def mergeSheets(self):
        container = self.current_container
        default = self.styleSource
        styles = list(container.manifest_items_of_type(OEB_STYLES));
        if not default in styles:
            container.add_file(default, get_resources(default))
            styles.append(default)
        with lopen(container.name_path_map[default], 'rb') as src:
            def_data = src.read()
        if len(styles) > 1:
            msheet = container.parsed(default)
            comments = [r for r in msheet.cssRules if r.type == r.COMMENT]
            for rule in comments:
                msheet.cssRules.remove(rule)
            for name in styles:
                if name == default: continue
                sheet = container.parsed(name)
                for rule in sheet.cssRules:
                    msheet.add(rule)
                container.remove_item(name)
            root = container.parsed(self.docName)
            head = root.find('h:head', namespaces = XPNSMAP)
            path = container.name_to_href(self.styleName, self.docName)
            link = etree.SubElement(head, XHTML('link'), rel = 'stylesheet', type = 'text/css', href = path)
            container.dirty(self.docName)
            container.dirty(default)
        rename_files(container, {default: self.styleName})
        self.remove_dummy_selectors()
        remove_unused_css(container, None, True, True)
        container.add_file(default, def_data)

    def arrange_folders(self):
        folder_map = {'style':'', 'image':'images', 'font':'fonts', 'audio':'audio', 'video':'video', 'opf':'', 'toc':''}
        name_map = rationalize_folders(self.current_container, folder_map)
        rename_files(self.current_container, name_map)

    def reformat(self):
        self.boss.commit_all_editors_to_container()
        self.boss.add_savepoint('Before: Reformat')

        self.docName = 'title.xhtml'
        self.styleSource = 'default.css'
        self.styleName = 'stylesheet.css'
        self.ref_name = 'ref'
        self.firstRun = False
        styles = list(self.current_container.manifest_items_of_type(OEB_STYLES));
        if not self.styleSource in styles:
            self.firstRun = True
        #self.inlines = ['i', 'b', 'u', 'em', 'strong', 'q', 'small', 'big', 'a', 'img', 'span', 'stanza']

        print("start reformatting")
        self.mergeDocs()
        print("merging docs... done")
        self.mergeSheets()
        print("styles... done")
        self.remove_spans()
        print("spans... done")
        self.trim()
        print("regex... done")
        self.insert_sections();
        print("sections... done")
        self.split()
        print("splits... done")
        self.toc_from_headers()
        print("TOC... done")
        self.arrange_folders()
        print("arranging folders... done")
        print("finished successfully")

        self.boss.apply_container_update_to_gui()
