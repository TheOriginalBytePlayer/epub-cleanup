#!/usr/bin/env python2
# vim:fileencoding=utf-8
from __future__ import absolute_import, division, print_function, unicode_literals

__license__ = 'GPL v3'
__copyright__ = '2014, Kovid Goyal <kovid at kovidgoyal.net>'

from calibre.customize import EditBookToolPlugin

PLUGIN_VERSION = (2, 4, 0)

class ReformatPlugin(EditBookToolPlugin):

    name = 'Reformat plugin'
    version = PLUGIN_VERSION
    author = 'Robert Świta'
    supported_platforms = ['windows', 'osx', 'linux']
    description = 'Simplifies structure and corrects format of EPUB files'
    minimum_calibre_version = (1, 46, 0)

    #: This field defines the GUI plugin class that contains all the code
    #: that actually does something. Its format is module_path:class_name
    #: The specified class must be defined in the specified module.
    actual_plugin = 'calibre_plugins.reformat_epub.main:TReformat'
